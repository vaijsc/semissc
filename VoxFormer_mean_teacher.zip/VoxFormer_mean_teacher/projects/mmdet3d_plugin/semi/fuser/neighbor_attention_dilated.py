import torch
from torch import nn
from torch.nn.init import trunc_normal_
import warnings
import os
from natten.functional import natten2dqkrpb, natten2dav

class HydraNeighborhoodAttention(nn.Module):
    def __init__(self,
                 dim,
                 kernel_sizes, # Array for kernel sizes
                 num_heads,
                 qkv_bias=True,
                 qk_scale=None,
                 attn_drop=0.,
                 proj_drop=0.,
                 dilations=[1], # Array of dilations
                 ):
        super().__init__()
        if len(kernel_sizes) == 1 and len(dilations) != 1:
            kernel_sizes = [kernel_sizes[0] for _ in range(len(dilations))]
        elif len(dilations) == 1 and len(kernel_sizes) != 1:
            dilations = [dilations[0] for _ in range(len(kernel_sizes))]
        assert(len(kernel_sizes) == len(dilations)),f"Number of kernels ({(kernel_sizes)}) must be the same as number of dilations ({(dilations)})"
        self.num_splits = len(kernel_sizes)
        self.num_heads = num_heads
        self.kernel_sizes = kernel_sizes
        self.dilations = dilations

        self.head_dim = dim // self.num_heads
        self.scale = qk_scale or self.head_dim ** -0.5

        asserts = []
        for i in range(len(kernel_sizes)):
            asserts.append(kernel_sizes[i] > 1 and kernel_sizes[i] % 2 == 1)
            if asserts[i] == False:
                warnings.warn(f"Kernel_size {kernel_sizes[i]} needs to be >1 and odd")
        assert(all(asserts)),f"Kernel sizes must be >1 AND odd. Got {kernel_sizes}"

        self.window_size = []
        for i in range(len(dilations)):
            self.window_size.append(self.kernel_sizes[i] * self.dilations[i])

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        # Needs to be fixed if we want uneven head splits. // is floored
        # division
        if num_heads % len(kernel_sizes) == 0:
            self.rpb = nn.ParameterList([nn.Parameter(torch.zeros(num_heads//self.num_splits, (2*k-1), (2*k-1))) for k in kernel_sizes])
            self.clean_partition = True
        else:
            diff = num_heads - self.num_splits * (num_heads // self.num_splits)
            rpb = [nn.Parameter(torch.zeros(num_heads//self.num_splits, (2*k-1), (2*k-1))) for k in kernel_sizes[:-diff]]
            for k in kernel_sizes[-diff:]:
                rpb.append(nn.Parameter(torch.zeros(num_heads//self.num_splits + 1, (2*k-1), (2*k-1))))
            assert(sum(r.shape[0] for r in rpb) == num_heads),f"Got {sum(r.shape[0] for r in rpb)} heads."
            self.rpb = nn.ParameterList(rpb)

            self.clean_partition = False
            self.shapes = [r.shape[0] for r in rpb]
            warnings.warn(f"Number of partitions ({self.num_splits}) do not "\
                    f"evenly divide the number of heads ({self.num_heads}). "\
                    f"We evenly divide the remainder between the last {diff} "\
                    f"heads This may cause unexpected behavior. Your head " \
                    f"partitions look like {self.shapes}")

        [trunc_normal_(rpb, std=0.02, mean=0.0, a=-2., b=2.) for rpb in self.rpb]
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, Hp, Wp, C = x.shape
        H, W = Hp, Wp
        qkv = self.qkv(x).reshape(B, H, W, 3, self.num_heads, self.head_dim).permute(3, 0, 4, 1, 2, 5)

        q, k, v = qkv.chunk(3, dim=0)
        q = q.squeeze(0) * self.scale
        k = k.squeeze(0)
        v = v.squeeze(0)

        if self.clean_partition:
            q = q.chunk(self.num_splits, dim=1)
            k = k.chunk(self.num_splits, dim=1)
            v = v.chunk(self.num_splits, dim=1)
        else:
            i = 0
            _q = []
            _k = []
            _v = []
            for h in self.shapes:
                _q.append(q[:, i:i+h, :, :])
                _k.append(k[:, i:i+h, :, :])
                _v.append(v[:, i:i+h, :, :])
                i = i+h
            q, k, v = _q, _k, _v


        attention = [natten2dqkrpb(_q, _k, _rpb, _kernel_size, _dilation) \
                     for _q,_k,_rpb,_kernel_size,_dilation in zip(q, k, self.rpb, self.kernel_sizes, self.dilations)]
        attention = [a.softmax(dim=-1) for a in attention]
        attention = [self.attn_drop(a) for a in attention]

        x = [natten2dav(_attn, _v, _k, _d) \
             for _attn, _v, _k, _d in zip(attention, v, self.kernel_sizes, self.dilations)]

        x = torch.cat(x, dim=1)
        x = x.permute(0, 2, 3, 1, 4).reshape(B, H, W, C)
        return self.proj_drop(self.proj(x))


class HydraNeighborAttention(nn.Module):
    def __init__(self, dim, outdim):
        super().__init__()
        self.na2d = HydraNeighborhoodAttention(dim=148, num_heads=4, kernel_sizes=[7], dilations=[1,2,4,16])
        self.na2d_1 = HydraNeighborhoodAttention(dim=148, num_heads=4, kernel_sizes=[7], dilations=[1,2,4,16])
        self.reducer = nn.Linear(dim, outdim)

    def forward(self, query, query_pos=None):
        inp_residual = query.clone()
        if query_pos != None:
            query = query + query_pos

        out = self.na2d(query) + inp_residual
        out = self.na2d_1(out) + out
        out = self.reducer(out)
        return out



if __name__ == "__main__":
    x = torch.randn(2, 128, 128, 16, 148).cuda()
    # model = HydraNeighborAttention(dim=148, outdim=128).cuda()
    # x = x.reshape(2, 512, 512, 148)
    # out = model(x)
    # print(out.shape)
    # B, Hp, Wp, C = x.shape