import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import sys

EPS = 1e-4

from functools import partial
from einops.layers.torch import Rearrange, Reduce

from projects.mmdet3d_plugin.semi.fuser.ops.modules import MSDeformAttn, MSDeformAttn3D

class VanillaSelfAttention(nn.Module):
    def __init__(self, dim=128, outdim=128, dropout=0.1):
        super(VanillaSelfAttention, self).__init__()
        self.dim = dim 
        self.dropout = nn.Dropout(dropout)
        self.deformable_attention = MSDeformAttn(d_model=dim, n_levels=2, n_heads=4, n_points=16)
        self.output_proj = nn.Linear(dim, dim)
        self.reducer = nn.Linear(dim, outdim)
    def get_reference_points(self, H, W, Z=8, num_points_in_pillar=4, dim='3d', bs=1, device='cuda', dtype=torch.float):
        """Get the reference points used in DCA and DSA.
        Args:
            H, W: spatial shape of bev.
            Z: hight of pillar.
            D: sample D points uniformly from each pillar.
            device (obj:`device`): The device where
                reference_points should be.
        Returns:
            Tensor: reference points used in decoder, has \
                shape (bs, num_keys, num_levels, 2).
        """

        # reference points in 3D space, used in spatial cross-attention (SCA)
        if dim == '3d':
            zs = torch.linspace(0.5, Z - 0.5, num_points_in_pillar, dtype=dtype,
                                device=device).view(-1, 1, 1).expand(num_points_in_pillar, H, W) / Z
            xs = torch.linspace(0.5, W - 0.5, W, dtype=dtype,
                                device=device).view(1, 1, W).expand(num_points_in_pillar, H, W) / W
            ys = torch.linspace(0.5, H - 0.5, H, dtype=dtype,
                                device=device).view(1, H, 1).expand(num_points_in_pillar, H, W) / H
            ref_3d = torch.stack((xs, ys, zs), -1)
            ref_3d = ref_3d.permute(0, 3, 1, 2).flatten(2).permute(0, 2, 1)
            ref_3d = ref_3d[None].repeat(bs, 1, 1, 1)
            return ref_3d

        # reference points on 2D bev plane, used in temporal self-attention (TSA).
        elif dim == '2d':
            ref_y, ref_x = torch.meshgrid(
                torch.linspace(
                    0.5, H - 0.5, H, dtype=dtype, device=device),
                torch.linspace(
                    0.5, W - 0.5, W, dtype=dtype, device=device)
            )
            ref_y = ref_y.reshape(-1)[None] / H
            ref_x = ref_x.reshape(-1)[None] / W
            ref_2d = torch.stack((ref_x, ref_y), -1)
            ref_2d = ref_2d.repeat(bs, 1, 1).unsqueeze(2)
            return ref_2d

    def forward(self, query, query_pos=None):
        '''
        query: (B, N, C)
        '''
        inp_residual = query.clone()

        if query_pos is not None:
            query = query + query_pos

        B, N, C = query.shape
        device = query.device

        # Z, X = 200, 200
        # ref_z, ref_x = torch.meshgrid(
        #     torch.linspace(0.5, Z-0.5, Z, dtype=torch.float, device=query.device),
        #     torch.linspace(0.5, X-0.5, X, dtype=torch.float, device=query.device)
        # )
        # ref_z = ref_z.reshape(-1)[None] / Z
        # ref_x = ref_x.reshape(-1)[None] / X
        # reference_points = torch.stack((ref_z, ref_x), -1)
        # reference_points = reference_points.repeat(B, 1, 1).unsqueeze(2) # (B, N, 1, 2)

        reference_points = self.get_reference_points(512, 512, dim='2d', bs=B, device=query.device, dtype=query.dtype)
        
        B, N, C = query.shape
        input_spatial_shapes = query.new_zeros([1,2]).long()
        input_spatial_shapes[:] = 512

        input_level_start_index = query.new_zeros([1,]).long()
        queries = self.deformable_attention(query, reference_points, query.clone(), 
            input_spatial_shapes.detach(), input_level_start_index.detach())

        queries = self.output_proj(queries)

        temp =  self.dropout(queries) + inp_residual
        return self.reducer(temp)
        
# if __name__ == "__main__":
#     x = torch.randn(2, 128, 128, 16, 192).cuda()
#     x = x.reshape(2, -1, 192)
#     model = VanillaSelfAttention(192).cuda()
#     y = model(x)
#     print(y.shape)
#     print(torch.cuda.memory_allocated() / 1024 / 1024)
