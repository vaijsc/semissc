# ---------------------------------------------
# Copyright (c) OpenMMLab. All rights reserved.
# ---------------------------------------------

from tkinter.messagebox import NO
import torch
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS, build_detector
from mmdet3d.core import bbox3d2result
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
import time
import copy
import numpy as np
import mmdet3d
from projects.mmdet3d_plugin.ssod.utils.structure_utils import dict_split, weighted_loss

from torch.nn import functional as F
from mmdet3d.models import build_model
import torch.nn as nn

from mmdet3d.models.detectors.base import Base3DDetector
from projects.mmdet3d_plugin.ssod.models.multi_stream_detector import MultiSteamDetector
# from projects.mmdet3d_plugin.semi.utils.ssc_loss import DiceLoss, lovasz_softmax, sem_scal_loss, geo_scal_loss, DINOLoss
from projects.mmdet3d_plugin.semi.utils.box_gen import BoxMaskGenerator
from monoscene.data.utils.helpers import (vox2pix, compute_local_frustums, compute_local_frustum, compute_CP_mega_matrix,)
import torchvision


def multinomial_kl(log_prob1, log_prob2):   # compute KL loss on log_prob
    
    # qlogq = (q * logq).sum(dim=1).mean(dim=0)
    # qlogp = (q * logp).sum(dim=1).mean(dim=0)
    kl = (log_prob1.exp() * (log_prob1 - log_prob2)).sum(dim=1)
    return kl

def sum_except_batch(x, num_dims=1):
    return x.reshape(*x.shape[:num_dims], -1).sum(-1)


@DETECTORS.register_module()
class SemiBaseGeoFusion(MultiSteamDetector):
    """BEVFormer.
    Args:
        video_test_mode (bool): Decide whether to use temporal information during inference.
    """

    def __init__(self,
                 segmentor_student,
                 segmentor_teacher,
                 cutmix=False,
                 pseudo_labelling=False,
                 pseudo_depth=False,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 *kwargs,
                 ):

        super(SemiBaseGeoFusion,
              self).__init__(
                            dict(teacher=build_model(segmentor_teacher), student=build_model(segmentor_student)),

                            train_cfg=train_cfg,
                            test_cfg=test_cfg,)
        self.cutmix = cutmix
        self.pseudo_depth = pseudo_depth
        if not self.cutmix:
            self.loss = nn.KLDivLoss(reduction='batchmean')
            # self.pred_loss = nn.KLDivLoss(reduction='batchmean')
            self.dropout = nn.Dropout3d(p=0.2)
            # self.loss = nn.MSELoss()
            self.pred_loss = nn.MSELoss()
        else:
            self.loss = nn.MSELoss()
        
        self.freeze(self.teacher)
        self.count = 0
        self.tps = 1
        self.pseudo_labelling = pseudo_labelling
        if self.cutmix:
            mask_prop_range=0.5
            boxmask_n_boxes = 1
            boxmask_fixed_aspect_ratio = False
            boxmask_by_size = False
            boxmask_outside_bounds = False
            boxmask_no_invert = False
            self.mask_generator = BoxMaskGenerator(prop_range=mask_prop_range, n_boxes=boxmask_n_boxes,
                                                        random_aspect_ratio=not boxmask_fixed_aspect_ratio,
                                                        prop_by_area=not boxmask_by_size, within_bounds=not boxmask_outside_bounds,
                                                        invert=not boxmask_no_invert)

    @staticmethod
    def freeze(model: nn.Module) -> None:
        """Freeze the model."""
        model.eval()
        for param in model.parameters():
            param.requires_grad = False

    def forward_dummy(self, img):
        dummy_metas = None
        return self.forward_test(img=img, img_metas=[[dummy_metas]])

    def forward_test(self,
                    points=None,
                    img_metas=None,
                    img_inputs=None,
                    gt_occ=None,
                    points_occ=None,
                    points_uv=None,
                    **kwargs,):
        kwargs.update({"img_inputs": img_inputs[0]})
        kwargs.update({"gt_occ": gt_occ})
        kwargs.update({"img_metas": img_metas})
        out = self.teacher.forward_test(**kwargs)
        
        return out

    def forward(self, return_loss=True, **kwargs):
        """Calls either forward_train or forward_test depending on whether
        return_loss=True.
        Note this setting will change the expected inputs. When
        `return_loss=True`, img and img_metas are single-nested (i.e.
        torch.Tensor and list[dict]), and when `resturn_loss=False`, img and
        img_metas should be double nested (i.e.  list[torch.Tensor],
        list[list[dict]]), with the outer list indicating test time
        augmentations.
        """
        if return_loss:
            return self.forward_train(**kwargs)
        else:
            out = self.teacher.forward_test(**kwargs)
            # breakpoint()
            # logits = out['output_voxels']
            # conf, pred = torch.max(logits, dim=1)
            # out['output_scores'] = conf
            out['output_scores'] = None
            return out
    

    @auto_fp16(apply_to=('img', 'points'))
    def forward_train(self,
                    points=None,
                    img_metas=None,
                    img_inputs=None,
                    gt_occ=None,
                    points_occ=None,
                    points_uv=None,
                    gt_occ_1_2=None,
                    **kwargs,
                    ):   
        ## ##     
        kwargs.update({"img_inputs": img_inputs})
        kwargs.update({"gt_occ": gt_occ})
        kwargs.update({"gt_occ_1_2": gt_occ_1_2})
        kwargs.update({"img_metas": img_metas})
        kwargs.update({"tag": [meta["tag"] for meta in img_metas]})
        data_groups = dict_split(kwargs, "tag")
        losses = dict()
        if not self.cutmix:
            ## Use for batch size = 2 ##
            loss_supervised, student_out, teacher_out = self.get_features(img_inputs=img_inputs, gt_occ=gt_occ, gt_occ_1_2=gt_occ_1_2, img_metas=img_metas, data_groups=data_groups)
            if self.pseudo_depth:
                if student_out != None:
                    losses['pseudo_depth'] = student_out['loss_depth'] / 4.0
                    student_out.pop('loss_depth')
            self.process_loss(losses, loss_supervised, student_out, teacher_out)
        else:
            breakpoint()
        return losses

    def process_loss(self, losses, loss_supervised, student_out, teacher_out):
        if loss_supervised != None:
            losses.update(loss_supervised)
        
        if student_out != None:
            
            student_mask_cls_results = student_out['mask_cls_results'] #batch, query, classes
            teacher_mask_cls_results = teacher_out['mask_cls_results']
            # student_mask_pred_results = student_out['mask_pred_results']
            # teacher_mask_pred_results = teacher_out['mask_pred_results']
            # ## Pseudo Labeling & Mixing ##
            # if True:
            #     mask_cls = F.softmax(student_mask_cls_results, dim=-1)[..., :-1]
            #     mask_pred = student_out['mask_pred_results'].sigmoid()
            #     output_voxels = torch.einsum("bqc, bqxyz->bcxyz", mask_cls, mask_pred)
            #     sup_aux_loss = nn.functional.cross_entropy(output_voxels, teacher_out['target_voxels'], ignore_index=255)
            #     losses['sup_aux_loss'] = sup_aux_loss

            unsup_temp = dict()
            two = True
            if two:
                student_mask_cls = F.log_softmax(student_mask_cls_results, dim=-1)
                teacher_mask_cls = F.softmax(teacher_mask_cls_results, dim=-1)
                unsup_temp['cls_consistencty_loss'] = self.loss(student_mask_cls, teacher_mask_cls.detach())     

                # student_mask_pred_results = F.log_softmax(student_out['mask_pred_results'], dim=1) #batch, query, H, W, D
                # teacher_mask_pred_results = F.softmax(teacher_out['mask_pred_results'], dim=1)
                student_mask_pred_results = student_out['mask_pred_results'] #batch, query, H, W, D
                teacher_mask_pred_results = teacher_out['mask_pred_results']
                unsup_temp['pred_consistencty_loss'] = self.pred_loss(student_mask_pred_results, teacher_mask_pred_results.detach())       
            else:
                mask_cls = F.softmax(student_mask_cls_results, dim=-1)[..., :-1]
                mask_pred = student_out['mask_pred_results'].sigmoid()
                output_voxels = torch.einsum("bqc, bqxyz->bcxyz", mask_cls, mask_pred)
                
                mask_cls_teach = F.softmax(teacher_mask_cls_results, dim=-1)[..., :-1]
                mask_pred_teach = teacher_out['mask_pred_results'].sigmoid()
                output_voxels_teach = torch.einsum("bqc, bqxyz->bcxyz", mask_cls_teach, mask_pred_teach)

                output_voxels_teach = F.softmax(output_voxels_teach / 0.04, dim=1)
                loss = torch.sum(-output_voxels_teach * F.log_softmax(output_voxels / 0.1, dim=1), dim=1)
                unsup_temp['unsup_nll_loss'] = loss

            unsup_loss = weighted_loss(
                unsup_temp,
                weight=1,
                warmup=500,
            )

            

            losses.update(**unsup_loss)

    def get_features(self, 
                    points=None,
                    img_metas=None,
                    img_inputs=None,
                    gt_occ=None,
                    gt_occ_1_2=None,
                    points_occ=None,
                    points_uv=None,
                    data_groups=None):
        # 3 cases, sup-sup, sup-unsup, unsup-unsup
        if len(data_groups) == 3: #sup-unsup

            with torch.no_grad():
                data_groups['unsup_teacher']['img_inputs']  = data_groups['unsup_teacher']['img_inputs'][0] 
                data_groups['unsup_teacher']['tag'] =True
                teacher_output = self.teacher.forward_test(**data_groups['unsup_teacher'])

            new_img_inputs = [torch.stack((tensor1, tensor2)) for tensor1, tensor2 in \
                              zip(data_groups['sup']['img_inputs'][0], data_groups['unsup_student']['img_inputs'][0])]
            new_gt_occ_1_2_inputs = torch.cat((data_groups['sup']['gt_occ_1_2'], data_groups['unsup_student']['gt_occ_1_2']))
            voxel_feats, img_feats, depth = self.student.extract_feat(points, img=new_img_inputs, img_metas=img_metas, gt_occ=new_gt_occ_1_2_inputs)
            ### Supervised ###
            sup_voxel_feats = [i[0].unsqueeze(0) for i in voxel_feats]
            losses_occupancy = self.student.forward_pts_train(sup_voxel_feats, data_groups['sup']['gt_occ'], points_occ, data_groups['sup']['img_metas'], img_feats=img_feats[0].unsqueeze(0))
            loss_depth = self.student.img_view_transformer.get_depth_loss(data_groups['sup']['img_inputs'][0][7][None], depth[0][None])
            losses_occupancy['loss_depth'] = loss_depth
            ### Unsupervised ###
            unsup_student_voxel_feats = [self.dropout(i[1].unsqueeze(0)) for i in voxel_feats]
            student_output = self.student.pts_bbox_head.simple_test(voxel_feats=unsup_student_voxel_feats, points=points_occ, img_metas=data_groups['unsup_student']['img_metas'], img_feats=img_feats[1].unsqueeze(0), points_uv=points_uv, tag=True)
            
            if self.pseudo_depth:
                student_output['loss_depth'] = self.student.img_view_transformer.get_depth_loss(data_groups['unsup_student']['img_inputs'][0][7][None], depth[1][None])
                
            
            

        elif len(data_groups) == 2: #unsup-unsup
            data_groups['unsup_teacher']['img_inputs'] = [torch.stack((tensor1, tensor2)) for tensor1, tensor2 in zip(data_groups['unsup_teacher']['img_inputs'][0], data_groups['unsup_teacher']['img_inputs'][1])]
            data_groups['unsup_student']['img_inputs'] = [torch.stack((tensor1, tensor2)) for tensor1, tensor2 in zip(data_groups['unsup_student']['img_inputs'][0], data_groups['unsup_student']['img_inputs'][1])]
            data_groups['unsup_student']['tag'] = True
            data_groups['unsup_student']['tag'] = True
            with torch.no_grad():
                teacher_output = self.teacher.forward_test(**data_groups['unsup_teacher'])
                
            student_output = self.student.forward_test(**data_groups['unsup_student'])

            if self.pseudo_depth:
                student_output['loss_depth'] = self.student.img_view_transformer.get_depth_loss(data_groups['unsup_student']['img_inputs'][7], student_output['depth'])
                
            losses_occupancy = None            

        elif len(data_groups) == 1: #sup-sup
            data_groups['sup']['img_inputs'] = [torch.stack((tensor1, tensor2)) for tensor1, tensor2 in zip(data_groups['sup']['img_inputs'][0], data_groups['sup']['img_inputs'][1])]
            losses_occupancy = self.student(**data_groups['sup'])
            student_output = None
            teacher_output = None
   
        else:
            breakpoint()

        return losses_occupancy, student_output, teacher_output

    def _load_from_state_dict(
        self,
        state_dict,
        prefix,
        local_metadata,
        strict,
        missing_keys,
        unexpected_keys,
        error_msgs,):
        if not any(["student" in key or "teacher" in key for key in state_dict.keys()]):
            keys = list(state_dict.keys())
            state_dict.update({"teacher." + k: state_dict[k] for k in keys})
            state_dict.update({"student." + k: state_dict[k] for k in keys})
            # only update teacher - as teacher must hold advantage over the student
            for k in keys:
                state_dict.pop(k)

        return super()._load_from_state_dict(
            state_dict,
            prefix,
            local_metadata,
            strict,
            missing_keys,
            unexpected_keys,
            error_msgs,
        )
