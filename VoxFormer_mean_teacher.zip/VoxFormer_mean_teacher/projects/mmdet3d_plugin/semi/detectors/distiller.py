# ---------------------------------------------
# Copyright (c) OpenMMLab. All rights reserved.
# ---------------------------------------------

from tkinter.messagebox import NO
import torch
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS, build_detector
from mmdet3d.core import bbox3d2result
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
import time
import copy
import numpy as np
import mmdet3d
from projects.mmdet3d_plugin.ssod.utils.structure_utils import dict_split, weighted_loss

from torch.nn import functional as F
from mmdet3d.models import build_model
import torch.nn as nn

from mmdet3d.models.detectors.base import Base3DDetector
from projects.mmdet3d_plugin.ssod.models.multi_stream_detector import MultiSteamDetector
# from projects.mmdet3d_plugin.semi.utils.ssc_loss import DiceLoss, lovasz_softmax, sem_scal_loss, geo_scal_loss, DINOLoss
from projects.mmdet3d_plugin.semi.utils.box_gen import BoxMaskGenerator
from monoscene.data.utils.helpers import (vox2pix, compute_local_frustums, compute_local_frustum, compute_CP_mega_matrix,)
import torchvision
from projects.mmdet3d_plugin.semi.distiller.SP import SP
from projects.mmdet3d_plugin.semi.distiller.pairwise import sim_dis_compute

@DETECTORS.register_module()
class DistillBase(MultiSteamDetector):
    """BEVFormer.
    Args:
        video_test_mode (bool): Decide whether to use temporal information during inference.
    """

    def __init__(self,
                 segmentor_student,
                 segmentor_teacher,
                 distill="mse",
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 *kwargs,
                 ):

        super(DistillBase,
              self).__init__(
                            dict(teacher=build_model(segmentor_teacher), student=build_model(segmentor_student)),
                            train_cfg=train_cfg,
                            test_cfg=test_cfg,)        
        self.freeze(self.teacher)
        self.distil_type = distill
        if self.distil_type == "mse":
            self.distil_loss = nn.MSELoss()
        elif self.distil_type == "pairwise":
            pass
        else:
            self.distil_loss = SP()
    
    @staticmethod
    def freeze(model: nn.Module) -> None:
        """Freeze the model."""
        model.eval()
        for param in model.parameters():
            param.requires_grad = False


    def forward(self, return_loss=True, **kwargs):
        """Calls either forward_train or forward_test depending on whether
        return_loss=True.
        Note this setting will change the expected inputs. When
        `return_loss=True`, img and img_metas are single-nested (i.e.
        torch.Tensor and list[dict]), and when `resturn_loss=False`, img and
        img_metas should be double nested (i.e.  list[torch.Tensor],
        list[list[dict]]), with the outer list indicating test time
        augmentations.
        """
        if return_loss:
            return self.forward_train(**kwargs)
        else:
            out = self.student.forward_test(**kwargs)
            return out
    
    @auto_fp16(apply_to=('img', 'points'))
    def forward_train(self,
            points=None,
            img_metas=None,
            img_inputs=None,
            gt_occ=None,
            points_occ=None,
            points_uv=None,
            gt_occ_1_2=None,
            **kwargs,):
        
        with torch.no_grad():
            voxel_feats_teacher, _, _ = self.teacher.extract_feat(points, img=img_inputs, gt_occ=gt_occ_1_2, img_metas=img_metas)
        
        voxel_feats, img_feats, depth = self.student.extract_feat(points, img=img_inputs, img_metas=img_metas)
        # training losses
        losses = dict()
        if len(img_inputs[7].shape) == 3:
            losses['loss_depth'] = self.student.img_view_transformer.get_depth_loss(img_inputs[7].unsqueeze(0), depth)
        else:
            losses['loss_depth'] = self.student.img_view_transformer.get_depth_loss(img_inputs[7], depth)
        losses_occupancy = self.student.forward_pts_train(voxel_feats, gt_occ, points_occ, img_metas, img_feats=img_feats, points_uv=points_uv, **kwargs)
        losses.update(losses_occupancy)

        # Distillation losses
        if self.distil_type == "mse":
            distil_loss = 0
            for i in range(len(voxel_feats)):
                distil_loss += self.distil_loss(voxel_feats[i], voxel_feats_teacher[i].detach())
            losses['distil_loss'] = distil_loss
        elif self.distil_type == "pairwise":
            breakpoint()
            temp_t = voxel_feats_teacher[1].detach()
            temp_s = voxel_feats[0]
            loss = sim_dis_compute(temp_s, temp_t)
            
        else:
            distil_loss = 0
            for i in range(len(voxel_feats)):
                temp_t = voxel_feats_teacher[i].detach().permute(1,2,3,4,0)
                temp_t = temp_t.reshape(temp_t.shape[0], -1)

                temp_s = voxel_feats[i].permute(1,2,3,4,0)
                temp_s = temp_s.reshape(temp_s.shape[0], -1)

                distil_loss += self.distil_loss(temp_s, temp_t)

            losses['distil_loss'] = distil_loss

        return losses