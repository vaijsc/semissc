# ---------------------------------------------
# Copyright (c) OpenMMLab. All rights reserved.
# ---------------------------------------------

from tkinter.messagebox import NO
import torch
from mmcv.runner import force_fp32, auto_fp16
from mmdet.models import DETECTORS, build_detector
from mmdet3d.core import bbox3d2result
from mmdet3d.models.detectors.mvx_two_stage import MVXTwoStageDetector
import time
import copy
import numpy as np
import mmdet3d

from torch.nn import functional as F
from mmdet3d.models import build_model
import torch.nn as nn

from mmdet3d.models.detectors.base import Base3DDetector
from projects.mmdet3d_plugin.ssod.models.multi_stream_detector import MultiSteamDetector
import torchvision

import torchvision.transforms as transforms

@DETECTORS.register_module()
class SemiBase(MultiSteamDetector):
    """BEVFormer.
    Args:
        video_test_mode (bool): Decide whether to use temporal information during inference.
    """

    def __init__(self,
                 segmentor_student,
                 segmentor_teacher,
                 cutmix=False,
                 pseudo_labelling=False,
                 pseudo_depth=False,
                 use_grid_mask=False,
                 pts_voxel_layer=None,
                 pts_voxel_encoder=None,
                 pts_middle_encoder=None,
                 pts_fusion_layer=None,
                 img_backbone=None,
                 pts_backbone=None,
                 img_neck=None,
                 pts_neck=None,
                 pts_bbox_head=None,
                 img_roi_head=None,
                 img_rpn_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 *kwargs,
                 ):

        super(SemiBase,
              self).__init__(
                            dict(teacher=build_model(segmentor_teacher), student=build_model(segmentor_student)),

                            train_cfg=train_cfg,
                            test_cfg=test_cfg,)
        self.freeze(self.teacher)
        self.count = 0
        self.tps = 1
        self.pseudo_labelling = pseudo_labelling
        unsup_transforms = transforms.RandomApply(torch.nn.ModuleList([
                                                    transforms.ColorJitter(brightness=32, 
                                                                           contrast=(0.5, 1.5),
                                                                           saturation=(0.5, 1.5),
                                                                            hue=0.25),
                                                    transforms.RandomAdjustSharpness(0.5),
                                                    transforms.GaussianBlur((3,3))]), p=0.5)
        self.scripted_transforms = unsup_transforms
        self.loss = nn.MSELoss()
    @staticmethod
    def freeze(model: nn.Module) -> None:
        """Freeze the model."""
        model.eval()
        for param in model.parameters():
            param.requires_grad = False

    def forward_dummy(self, img):
        dummy_metas = None
        return self.forward_test(img=img, img_metas=[[dummy_metas]])

    def forward_test(self,
                    points=None,
                    img_metas=None,
                    img_inputs=None,
                    gt_occ=None,
                    points_occ=None,
                    points_uv=None,
                    **kwargs,):
        kwargs.update({"img_inputs": img_inputs[0]})
        kwargs.update({"gt_occ": gt_occ})
        kwargs.update({"img_metas": img_metas})
        out = self.teacher.forward_test(**kwargs)
        
        return out

    def forward(self, return_loss=True, **kwargs):
        """Calls either forward_train or forward_test depending on whether
        return_loss=True.
        Note this setting will change the expected inputs. When
        `return_loss=True`, img and img_metas are single-nested (i.e.
        torch.Tensor and list[dict]), and when `resturn_loss=False`, img and
        img_metas should be double nested (i.e.  list[torch.Tensor],
        list[list[dict]]), with the outer list indicating test time
        augmentations.
        """
        if return_loss:
            return self.forward_train(**kwargs)
        else:
            out = self.teacher.forward_test(**kwargs)
            return out
    

    @auto_fp16(apply_to=('img', 'points'))
    def forward_train(self,
                      img_metas=None,
                      img=None,
                      target=None,
                      **kwargs,
                    ):   
        ## ##     
        tag = img_metas[0][0]['tag']
        losses = dict()
        if tag == "sup":
            sup_loss = self.student.forward_train(img_metas, img, target)
            print(tag)
            losses.update(sup_loss)
        elif tag == "unsup":
            
            temp = self.scripted_transforms(img[0,0])
            student_out = self.student.forward_unsup(img_metas, temp[None, None], None)
            with torch.no_grad():
                teacher_out = self.teacher.forward_unsup(img_metas, img, None)

            unsup_loss = self.loss(student_out['y_pred'], teacher_out['y_pred'].detach())
            losses['unsup_consistency_loss'] = unsup_loss

        return losses

    def _load_from_state_dict(
        self,
        state_dict,
        prefix,
        local_metadata,
        strict,
        missing_keys,
        unexpected_keys,
        error_msgs,):
        if not any(["student" in key or "teacher" in key for key in state_dict.keys()]):
            keys = list(state_dict.keys())
            state_dict.update({"teacher." + k: state_dict[k] for k in keys})
            state_dict.update({"student." + k: state_dict[k] for k in keys})
            # only update teacher - as teacher must hold advantage over the student
            for k in keys:
                state_dict.pop(k)

        return super()._load_from_state_dict(
            state_dict,
            prefix,
            local_metadata,
            strict,
            missing_keys,
            unexpected_keys,
            error_msgs,
        )
